

clear all;
close all;
saveaddr = 'C:\Users\hunter\Desktop\Demos\˯�����ݿ�ucddb Data\ucddb_Data\'
% the number of samlpe about learning
ALL_num = 0;
subject_name = [2 3 5 6 7 10 12 14 15 17 18 19 20 21 22 23 24 25 26 27 9 28]; % ȥ��8 9 13 28  %ȥ��11 13 �缫����
PSG_duration = [22470 26478 24798 24267 24405 27211....
    25941 23239 27488 23684 24685 25573 22586 27409 23640 25850....
    27250 21350 25160 26791 27759 21660]; % ��Ӧ������ 8-->23041 9--> 27759  13-->24333  28-->21660 % ȥ�� 8-->23041 11-->27030 13-->24333 ����

for subject = 1:22
subject
if subject==7
    ha = 1;
end
subject_num = subject_name(subject);
Fs = 128;
%% load ecgdata
if subject_num > 9
%     subject_nuame_edf = strcat('ucddb0',num2str(subject_num),'_lifecard');
    subject_nuame_edf = strcat('ucddb0',num2str(subject_num)); 
else
%     subject_nuame_edf = strcat('ucddb00',num2str(subject_num),'_lifecard');
    subject_nuame_edf = strcat('ucddb00',num2str(subject_num));
end
% subject_filenuame_edf = strcat(subject_nuame_edf,'.edf');
% [Data Name] = readedf(subject_filenuame_edf);
% ecg_data_all = Data(1,size(Data,2)-PSG_duration(subject)*Fs-1500*Fs:end);

subject_filenuame_edf = strcat(subject_nuame_edf,'.rec');
[hdr, record] = edfread(subject_filenuame_edf);
ecg_data_all = record(6,:);

% figure;
%     plot(ecg_data_all);
%     hold on;
%     plot(s,'r');hold off;


%% load Stages data
if subject_num > 9
    subject_name_stages = strcat('ucddb0',num2str(subject_num),'_stage');
else 
    subject_name_stages = strcat('ucddb00',num2str(subject_num),'_stage');
end

% define the time
Time_segment = 60*2.5;
Times = floor((length(ecg_data_all)/Fs)/Time_segment);

subject_filename_stages = strcat(subject_name_stages,'.txt');
Stages = load(subject_filename_stages);

    dataLength = Times;
    segMean = average_soft(Stages,dataLength);
%     figure;plot(mean(abs(segMean)),'b');

HRV_segments = cell(1, Times);
% note the empty
empty = 0; 

for segments = 1:Times

segments
ecg_data = ecg_data_all(((segments-1)*Fs*Time_segment+1):segments*Fs*Time_segment) * 1000;

%%  �˲�
    output1_IIR = filter(mybandpassfilterIIR_ECG_500(2,40),ecg_data);
    output2_IIR = flip(output1_IIR);
    output3_IIR = filter(mybandpassfilterIIR_ECG_500(2,40),output2_IIR);
    s = flip(output3_IIR);
    
%     figure;
%     plot(ecg_data);hold on;
%     plot(s,'r');hold off;

%%  ��ȡ��ֵ
    ecg_detec = s(500:end);
    rate_type = 1;
    [window_width,peak_interval] = sample_results(Fs,rate_type);
    peaks = get_peak(ecg_detec,86,peak_interval,rate_type);

%%  �ҵ� HRV���쳣�㣻  Ҳ����˵����� ©�� �粫

    R_point_time_test = [];
    R_point_cor_Ectopic = zeros(4,50);  % ���������λ�������λ�ã��Ա��ں���HRV����ʱ��ȥ����
    Ectopic_num = 0;  %   ��¼��λ������ĸ���
    R_point_time_test = peaks(6:end-2);
    
    rr_flag = gjcRR(peaks,Fs); %��λΪms
    if length(R_point_time_test)>floor(Time_segment/1.4) && (length(find(rr_flag > 1200)) == 0)
%     [R_point_time_test, flag_Ectopic, R_point_cor_Ectopic] = HRV_optimizing(ecg_detec, R_point_time_test, R_point_cor_Ectopic, Fs, 1);
    %%%%     ��¼��λ���������
%     Ectopic_num = Ectopic_num + flag_Ectopic;
    %%%%  ���Ա����ĸ�״̬�ķ�ֵ��
    four_state_R_point_time(1,1) = {R_point_time_test(5:end-5)};

%     figure;
%     plot(ecg_detec,'b-');hold on;
%     plot(peaks, ecg_detec(peaks), 'ro');hold on;
%     plot(round(R_point_time_test), ecg_detec(round(R_point_time_test)), 'k*');hold off;
%     legend('�ĵ粨��','ԭʼ�ķ�ֵ��','����֮��ķ�ֵ��');
%%  ��������֮���HRV����
    rr_correct = [];
    rr_correct = gjcRR(R_point_time_test,Fs); %��λΪms
    rr = gjcRR(peaks,Fs); %��λΪms
%     figure(10);
%     % subplot(2,2,state_select);
%     plot(rr_correct,'r-');hold on;
%     plot(rr,'b-');hold off;
%     legend('����HRV����','HRV����');

    HRV_segments(segments) = {rr_correct/Fs};

%%  ���� HRV ����

HRV_mode = [];
HRV_mode(:,1) = R_point_time_test / 1000;
HRV_mode(:,2) = [ mean(diff(R_point_time_test / 1000)) diff(R_point_time_test) / 1000 ];
%%% import the time domin parameter 
SDNNi= 1;
pNNx = 50;
Window = 30;
Overlap = 15;
%%% import the freq domin parameter
% VLF = [0 0.03];
% LF = [0.03 max_FRF(mode_select)-min_FRF(mode_select)];
% HF = [max_FRF(mode_select)-min_FRF(mode_select) max_FRF(mode_select)+min_FRF(mode_select)];
VLF = [0 0.04];
LF = [0.04 0.15];
HF = [0.15 0.4];
AR_Order = 16;
window_length = 256;
window_overlap = 128;
nfft = 256;
reFs = 2;
methods = {'ar','lomb'};  % 'ar','lomb','welch','wavelet'
flagPlot = 0; % plot the figure
%%% import the nolinear parameter
m = 2;
r = 0.1;
n1 = 4;
n2 = 100;
breakpoint = 13;
%%%  results
outputTime(segments) = {timeDomainHRV(HRV_mode, 1, 50)};
outputFreq(segments) = {freqDomainHRV(HRV_mode, VLF, LF, HF, AR_Order, window_length, window_overlap, nfft, reFs, methods, flagPlot)};
outputNolinear(segments) = {nonlinearHRV(HRV_mode,m,r,n1,n2,breakpoint)};
outputPoincare(segments) = {poincareHRV(HRV_mode)};

% save HRV_mode.txt -ascii HRV_mode

%%% select the method

aHF_plotLomb(segments) = outputFreq{segments}.lomb.hrv.aHF;
aLF_plotLomb(segments) = outputFreq{segments}.lomb.hrv.aLF;
aVLF_plotLomb(segments) = outputFreq{segments}.lomb.hrv.aVLF;
LFHF_plotLomb(segments) = outputFreq{segments}.lomb.hrv.LFHF;

aHF_plotWelch(segments) = outputFreq{segments}.welch.hrv.aHF;
aLF_plotWelch(segments) = outputFreq{segments}.welch.hrv.aLF;
aVLF_plotWelch(segments) = outputFreq{segments}.welch.hrv.aVLF;
LFHF_plotWelch(segments) = outputFreq{segments}.welch.hrv.LFHF;

aHF_plotAR(segments) = outputFreq{segments}.ar.hrv.aHF;
aVLF_plotAR(segments) = outputFreq{segments}.ar.hrv.aVLF;
aLF_plotAR(segments) = outputFreq{segments}.ar.hrv.aLF;
LFHF_plotAR(segments) = outputFreq{segments}.ar.hrv.LFHF;

alpha_plot(:,segments) = outputNolinear{segments}.dfa.alpha;
alpha1_plot(:,segments) = outputNolinear{segments}.dfa.alpha1;
alpha2_plot(:,segments) = outputNolinear{segments}.dfa.alpha2;

ALL_num = ALL_num + 1;
FeatureSample(:,ALL_num) = [....
%     aHF_plotWelch(segments) aLF_plotWelch(segments) aVLF_plotWelch(segments) LFHF_plotWelch(segments)....
    aHF_plotLomb(segments) aLF_plotLomb(segments) aVLF_plotLomb(segments) LFHF_plotLomb(segments)....
    aHF_plotAR(segments) aLF_plotAR(segments) aVLF_plotAR(segments) LFHF_plotAR(segments)....
    alpha_plot(:,segments)' alpha1_plot(:,segments)' alpha2_plot(:,segments)'....
    mean(segMean(:,segments))];

% all parameters
% max = outputTime{segments}.max;	
% min	= outputTime{segments}.min;
% mean1 = outputTime{segments}.mean;
% median	= outputTime{segments}.median;
% SDNN = outputTime{segments}.SDNN;
% SDANN = outputTime{segments}.SDANN;
% NNx	= outputTime{segments}.NNx;
% pNNx = outputTime{segments}.pNNx;
% RMSSD = outputTime{segments}.RMSSD;
% SDNNi = outputTime{segments}.SDNNi;
% meanHR = outputTime{segments}.meanHR;
% sdHR = outputTime{segments}.sdHR;
% HRVTi = outputTime{segments}.HRVTi;
% TINN = outputTime{segments}.TINN;

% aVLF = outputFreq{segments}.lomb.hrv.aVLF;
% aLF = outputFreq{segments}.lomb.hrv.aLF;	
% aHF = outputFreq{segments}.lomb.hrv.aHF;	
% aTotal = outputFreq{segments}.lomb.hrv.aTotal;
% pVLF = outputFreq{segments}.lomb.hrv.pVLF;
% pLF = outputFreq{segments}.lomb.hrv.aLF;
% pHF = outputFreq{segments}.lomb.hrv.aHF;	
% nLF = outputFreq{segments}.lomb.hrv.aLF;	
% nHF = outputFreq{segments}.lomb.hrv.nHF;
% LFHF = outputFreq{segments}.lomb.hrv.LFHF;
% peakVLF = outputFreq{segments}.lomb.hrv.peakVLF;
% peakLF = outputFreq{segments}.lomb.hrv.peakLF;
% peakHF = outputFreq{segments}.lomb.hrv.peakHF;

% alpha = outputNolinear{segments}.dfa.alpha;
% alpha1 = outputNolinear{segments}.dfa.alpha1;
% alpha2 = outputNolinear{segments}.dfa.alpha2;
% [e A B] = outputNolinear{segments}.output.sampen;

% SD1(segments) = outputPoincare{segments}.SD1;
% SD2(segments) = outputPoincare{segments}.SD2;
    else 
        empty = empty + 1;
        
        aHF_plot(segments) = 0;
        aLF_plot(segments) = 0;
        aVLF_plot(segments) = 0;
        LFHF_plot(segments) = 0;
    end
end


%% ��ͼ
x1 = 10;
y1 = 10;
dx = 1810;
dy = 2110;
smooth_length = 3;

figure;
plot(smooth(mapminmax(aHF_plotLomb(1,:), 0, 1),smooth_length)*5,'y','linewidth',2);hold on;
plot(smooth(mapminmax(aLF_plotLomb(1,:), 0, 1),smooth_length)*5,'k','linewidth',2);hold on;
plot(smooth(mapminmax(aVLF_plotLomb(1,:), 0, 1),smooth_length)*5,'b','linewidth',2);hold on;
plot(smooth(mapminmax(LFHF_plotLomb(1,:), 0, 1),smooth_length)*5,'g','linewidth',2);hold on;
plot(mean(abs(segMean)),'r','linewidth',2);hold off;
legend('HFlomb','LFlomb','VLFlomb','LFlomb/HFlomb','SleepScore');
set(gcf,'position',[x1,y1,dx,dy]);%x1,y1��ͼ�����½�����(�����������Ļ)��dx,dy��ͼ��x,y����Ĵ�С�� 
saveas(gcf,[saveaddr, subject_nuame_edf, '_SleepFreqLombComp.bmp']);

figure;
plot(smooth(mapminmax(aHF_plotAR(1,:), 0, 1),smooth_length)*5,'y','linewidth',2);hold on;
plot(smooth(mapminmax(aLF_plotAR(1,:), 0, 1),smooth_length)*5,'k','linewidth',2);hold on;
plot(smooth(mapminmax(aVLF_plotAR(1,:), 0, 1),smooth_length)*5,'b','linewidth',2);hold on;
plot(smooth(mapminmax(LFHF_plotAR(1,:), 0, 1),smooth_length)*5,'g','linewidth',2);hold on;
plot(mean(abs(segMean)),'r','linewidth',2);hold off;
legend('HFar','LFar','VLFar','LFar/HFar','SleepScore');
set(gcf,'position',[x1,y1,dx,dy]);%x1,y1��ͼ�����½�����(�����������Ļ)��dx,dy��ͼ��x,y����Ĵ�С�� 
saveas(gcf,[saveaddr, subject_nuame_edf, '_SleepFreqARComp.bmp']);

figure;
plot(smooth(mapminmax(alpha_plot(1,:), 0, 1),smooth_length)*5,'r','linewidth',2);hold on;
plot(abs(smooth(mapminmax(alpha_plot(2,:), 0, 1),smooth_length)*5),'b','linewidth',2);hold on;
plot(mean(abs(segMean)),'k','linewidth',2);hold off;
legend('alphaC1','alphaC2','SleepScore');
grid minor;
set(gca,'XTick',20:20:110); 
set(gca,'XTicklabel',20:20:110);
set(gca,'YTick',0:1:5); 
set(gca,'YTicklabel',{'Wake','REM','S1','S2','S3','S4'});
set(gca, 'FontSize',16)
set(gcf,'position',[x1,y1,dx,dy]);%x1,y1��ͼ�����½�����(�����������Ļ)��dx,dy��ͼ��x,y����Ĵ�С�� 
saveas(gcf,[saveaddr, subject_nuame_edf, '_SleepTotalComp.bmp']);

figure;
plot(smooth(mapminmax(alpha1_plot(1,:), 0, 1),smooth_length)*5,'r','linewidth',2);hold on;
plot(abs(smooth(mapminmax(alpha1_plot(2,:), 0, 1),smooth_length)*5),'b','linewidth',2);hold on;
plot(mean(abs(segMean)),'k','linewidth',2);hold off;
legend('alphaShortC1','alphaShortC2','SleepScore');
grid minor;
set(gca,'XTick',20:20:110); 
set(gca,'XTicklabel',20:20:110);
set(gca,'YTick',0:1:5); 
set(gca,'YTicklabel',{'Wake','REM','S1','S2','S3','S4'});
set(gca, 'FontSize',16)
set(gcf,'position',[x1,y1,dx,dy]);%x1,y1��ͼ�����½�����(�����������Ļ)��dx,dy��ͼ��x,y����Ĵ�С�� 
saveas(gcf,[saveaddr, subject_nuame_edf, '_SleepShortComp.bmp']);

figure;
plot(smooth(mapminmax(alpha2_plot(1,:), 0, 1),smooth_length)*5,'r','linewidth',2);hold on;
plot(abs(smooth(mapminmax(alpha2_plot(2,:), 0, 1),smooth_length)*5),'b','linewidth',2);hold on;
plot(mean(abs(segMean)),'k','linewidth',2);hold off;
legend('alphaLongC1','alphaLongC2','SleepScore');
grid minor;
set(gca,'XTick',20:20:110); 
set(gca,'XTicklabel',20:20:110);
set(gca,'YTick',0:1:5); 
set(gca,'YTicklabel',{'Wake','REM','S1','S2','S3','S4'});
set(gca, 'FontSize',16)
set(gcf,'position',[x1,y1,dx,dy]);%x1,y1��ͼ�����½�����(�����������Ļ)��dx,dy��ͼ��x,y����Ĵ�С�� 
saveas(gcf,[saveaddr, subject_nuame_edf, '_SleepLongComp.bmp']);

figure;
plot(smooth(mapminmax(aHF_plotAR, 0, 1),smooth_length)*5,'r','linewidth',2);hold on;
plot(smooth(mapminmax(aHF_plotLomb, 0, 1),smooth_length)*5,'b','linewidth',2);hold on;
plot(mean(abs(segMean)),'k','linewidth',2);hold off;
legend('HFar','HFlomb','SleepScore');
grid minor;
set(gca,'XTick',20:20:110); 
set(gca,'XTicklabel',20:20:110);
set(gca,'YTick',0:1:5); 
set(gca,'YTicklabel',{'Wake','REM','S1','S2','S3','S4'});
set(gca, 'FontSize',16)
set(gcf,'position',[x1,y1,dx,dy]);%x1,y1��ͼ�����½�����(�����������Ļ)��dx,dy��ͼ��x,y����Ĵ�С�� 
saveas(gcf,[saveaddr, subject_nuame_edf, '_SleepHFComp.bmp']);

figure;
plot(smooth(mapminmax(aLF_plotAR, 0, 1),smooth_length)*5,'r','linewidth',2);hold on;
plot(smooth(mapminmax(aLF_plotLomb, 0, 1),smooth_length)*5,'b','linewidth',2);hold on;
plot(mean(abs(segMean)),'k','linewidth',2);hold off;
legend('LFar','LFlomb','SleepScore');
grid minor;
set(gca,'XTick',20:20:110); 
set(gca,'XTicklabel',20:20:110);
set(gca,'YTick',0:1:5); 
set(gca,'YTicklabel',{'Wake','REM','S1','S2','S3','S4'});
set(gca, 'FontSize',16)
set(gcf,'position',[x1,y1,dx,dy]);%x1,y1��ͼ�����½�����(�����������Ļ)��dx,dy��ͼ��x,y����Ĵ�С�� 
saveas(gcf,[saveaddr, subject_nuame_edf, '_SleepLFComp.bmp']);

figure;
plot(smooth(mapminmax(aVLF_plotAR, 0, 1),smooth_length)*5,'r','linewidth',2);hold on;
plot(smooth(mapminmax(aVLF_plotLomb, 0, 1),smooth_length)*5,'b','linewidth',2);hold on;
plot(mean(abs(segMean)),'k','linewidth',2);hold off;
legend('VLFar','VLFlomb','SleepScore');
grid minor;
set(gca,'XTick',20:20:110); 
set(gca,'XTicklabel',20:20:110);
set(gca,'YTick',0:1:5); 
set(gca,'YTicklabel',{'Wake','REM','S1','S2','S3','S4'});
set(gca, 'FontSize',16)
set(gcf,'position',[x1,y1,dx,dy]);%x1,y1��ͼ�����½�����(�����������Ļ)��dx,dy��ͼ��x,y����Ĵ�С�� 
saveas(gcf,[saveaddr, subject_nuame_edf, '_SleepVLFComp.bmp']);

figure;
plot(smooth(mapminmax(LFHF_plotAR, 0, 1),smooth_length)*5,'r','linewidth',2);hold on;
plot(smooth(mapminmax(LFHF_plotLomb, 0, 1),smooth_length)*5,'b','linewidth',2);hold on;
plot(mean(abs(segMean)),'k','linewidth',2);hold off;
legend('LFar/HFar','LFlomb/HFlomb','SleepScore');
grid minor;
set(gca,'XTick',20:20:110); 
set(gca,'XTicklabel',20:20:110);
set(gca,'YTick',0:1:5); 
set(gca,'YTicklabel',{'Wake','REM','S1','S2','S3','S4'});
set(gca, 'FontSize',16)
set(gcf,'position',[x1,y1,dx,dy]);%x1,y1��ͼ�����½�����(�����������Ļ)��dx,dy��ͼ��x,y����Ĵ�С�� 
saveas(gcf,[saveaddr, subject_nuame_edf, '_SleepLFHFComp.bmp']);

close all;


end


% figure;
% plot(e,'r');hold on;
% plot(mean(abs(segMean)),'k');hold off;
% figure;
% plot(SD1,'r');hold on;
% plot(mean(abs(segMean)),'k');hold off;
% figure;
% plot(SD2,'r');hold on;
% plot(mean(abs(segMean)),'k');hold off;

%% set the labels
% set(gca,'XTick',20:20:110); 
% set(gca,'XTicklabel',20:20:110);
% set(gca,'YTick',0:1:5); 
% set(gca,'YTicklabel',{'Wake','REM','S1','S2','S3','S4'});
% set(gca, 'FontSize',16)
% xlabel('Age(yr)', 'FontSize',16);
% ylabel('Sympathetic(LFa)', 'FontSize',16);
% grid on;
% xlim([20 110]);
% ylim([0 4]);
% hold on;



