
function segMean = average_soft(Stages, dataLength, flag)

if flag == 1
    Stages = smooth(Stages, 5);
end
segLength = floor(length(Stages)/dataLength);

segMean = zeros(segLength, dataLength);
for i = 1:dataLength
    segMean(:,i) = Stages(1 + (i - 1) * segLength:i * segLength);
end


