function RR=gjcRR(data,fs)
T=1/fs;
RR=[];
    for i=1:length(data)-1
        RR(i)=(data(i+1)-data(i))*T;
    end
end