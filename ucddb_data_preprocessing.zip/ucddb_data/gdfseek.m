function [status,POS,EDF]=gdfseek(arg1,offset,origin)
% [status,POS,EDF]=gdfseek(EDF_Struct,offset,origin)
% Currently, offset and origin are the number of (EDF) records. 
% It is considered to change it to seconds. 
% EDFSEEK FUNCTIONALITY MIGHT CHANGE IN FUTURE VERSIONS
%
% see also: fseek 

%	Version 0.46
%	12 May 1999
%	Copyright (c) 1997-1999 by Alois Schloegl
%	a.schloegl@ieee.org	

% This program is free software; you can redistribute it and/or
% modify it under the terms of the GNU General Public License
% as published by the Free Software Foundation; either version 2
% of the  License, or (at your option) any later version.
% 
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with this program; if not, write to the Free Software
% Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

%  12 May 1999 EDF.AS.startrec and EDF.AS.numrec included

EDF=arg1;
%EDF.AS.startrec=0;
EDF.AS.numrec=0;

if origin==-1 | origin=='bof'
	EDF.AS.startrec=offset;
        OFFSET=EDF.HeadLen+EDF.AS.bpb*offset;
        status=fseek(EDF.FILE.FID,OFFSET,origin);
elseif origin==0 | origin=='cof'
	EDF.AS.startrec=EDF.AS.startrec+offset;
        OFFSET=EDF.AS.bpb*offset;
        status=fseek(EDF.FILE.FID,OFFSET,origin);
elseif origin==1 | origin=='eof'
	EDF.AS.startrec=EDF.NRec+offset;
        OFFSET=EDF.HeadLen+EDF.AS.bpb*(EDF.NRec+offset);
        status=fseek(EDF.FILE.FID,OFFSET,origin);
end;

POS = (ftell(EDF.FILE.FID)-EDF.HeadLen)/EDF.AS.bpb;
if POS<1 | POS>EDF.NRec 
%if POS<EDF.HeadLen | POS>EDF.HeadLen+EDF.AS.spb*2*EDF.NRec 
        status=-1;
else
        status=0;
end;

