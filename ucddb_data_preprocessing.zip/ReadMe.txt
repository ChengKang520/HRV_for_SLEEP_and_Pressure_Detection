
##########################################################################
You can use script to preprocess these whole night ECG signal. Generally, my programe can fix 
ectopic beats and modify this type of beats to adjust the HRV sequence (avoid the very low or 
high frequency components).

Due to this limited dataset, actually, you can use more features of HRV to train this model or more
datasets. 

But I found that there are several major features we can apply to focus on.

kangkangsome@gmail.com 
Cheng Kang, 2019/07/15
##########################################################################